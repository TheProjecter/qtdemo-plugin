How to install QtDemo plugin?
-----------------------------

Install QtDemo plugin for QtCreator(v1.3.1):

1. Unpack precompiled QtDemo-xxx.zip into QtCreator's home directory, say, <QTCREATOR_HOME>.
2. Configure Qt SDK HOME for QtDemo plugin. 
   -- Open QtDemo plugin's property file in a editor: <QTCREATOR_HOME>/bin/QtDemo.properties. 
   -- Edit QT_SDK_HOME, let it point to your current Qt SDK home path.
3. Start your QtCreator IDE.
4. Enjoy!

See also: http://code.google.com/p/qtdemo-plugin/
